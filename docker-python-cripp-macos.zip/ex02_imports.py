# Goal: we want to import a function and then use it in the code

# Have a look at this documentation (open with CTRL+click): 
# https://docs.python.org/3/library/os.path.html#os.path.exists

# Can you import the "exists" member and use it 
# in order to see if the "recipes" folder exists? 
???

does_file_exist = ???("./recipes")
print(does_file_exist)

