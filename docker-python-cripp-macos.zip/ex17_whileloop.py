# Goal: The program shall repeatedly ask us for our name, until we type
#       exit.

name = None

# this while loop can run forever
while ???:
    name = input('What is your name: ')
    # if the name is "exit"
    # then we want to terminate the loop
    ???
    ???
    print(f'Hello {name}, nice to meet you!')
