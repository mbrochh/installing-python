# Goal: We want to familiarize ourselves with the if-else syntax
# Hint: the `len()` function can count the number of characters in a string

name = input("What is your name: ")

# create an if-else clause here
# if the name is longer than 5 characters
# then print "That's a long name"
# otherwise print "Nice and short!"
???
