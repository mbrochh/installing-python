# define a function called "squared"
# it shall have one input value
# inside the function, multiply the
# value with itself and return the result
???

print(squared(10))
