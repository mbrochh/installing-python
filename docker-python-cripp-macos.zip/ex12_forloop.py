# Goal: We want to calculate the sum of all numbers in the `numbers` list.

# This is our list of numbers:
numbers = [1, 4, 6, 7, 9, 10]

# This is the final result that we want to calculate and we start with 0:
total = 0

# create a for-loop that iterates over each item in numbers
???
    # inside the loop, increase the total 
    # by the current number
    ???

print(total)
