# Goal: We want to print "Hello World" and "Hallo Welt"
#       But we don't want to write down these words manually, instead we want
#       to take out the words out of the `words` list variable.
#       We also want to learn how to add several strings together using the
#       `+` operator.

words = [ ['Hello', 'Hallo'], ['World', 'Welt'] ]

# access the value 'Hello' from the words list, 
# add an empty space and then 
# add the value 'World' from the words list
message = ???
print(message)

# do the same for the values 'Hallo' and 'Welt'
# message = ???

print(message)
