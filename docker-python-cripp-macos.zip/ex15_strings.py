# Goal: We want to play around with f-strings. Here we want to construct
#       a string that looks like `./test/some_file.txt` without writing
#       that text manually, instead we want to use the text that we already
#       have stored in the three variables below:

output_folder = "./test"
file_name = "some_file"
file_extension = "txt"

# use an f-string to combine the three variables 
# shown at the top into one big string
# The end result should look like this: ./test/some_file.txt
output_path = ???
print(output_path)

