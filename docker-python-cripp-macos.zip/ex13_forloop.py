# Goal: We want to seperate the numbers in the `numbers` list.
#       We want all even numbers to be in the `even_numbers` list and all 
#       odd numbers to be in the `odd_numbers` list.

# Hint: You can use the modulo operator: `%`, which returns the remainder

# Example: 4 % 2 will return 0 (because 4 can be divided by 2 fully)

numbers = [4, 2, 6, 8, 3, 7, 8, 9, 1]
even_numbers = []
odd_numbers = []

# loop over each item in the numbers list
for ???:
    # if the current number is fully divisible by 2
    ???
        # then add it to the list even_numbers
        ???
    # otherwise
    ???
        # add it to the list of odd numbers
        ???

print(even_numbers)
print(odd_numbers)
