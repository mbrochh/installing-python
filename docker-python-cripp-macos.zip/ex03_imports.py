# Goal: We want to import a function and then use it in the code

# Have a look at this documentation (CTRL+click):
# https://docs.python.org/3/library/os.html#os.listdir

# Can you import the "listdir" member and
# use it in order to see all files inside the "recipes" folder?
???

files = ???("./recipes")
print(files)

