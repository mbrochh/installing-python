# Goal: We want create two string variables and the second one shall be made
#       based on the value of the first variable.

# create a variable called input_folder
# assign the value "./recipes" to that variable
???

# create a variable called output_folder
# assign the value of input_folder and also add "_renamed"
???

print(output_folder)
