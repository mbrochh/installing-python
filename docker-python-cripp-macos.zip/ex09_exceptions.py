# Goal: this program will crash when we enter a bad filename. We want to make
#       make sure that it ends gracefully instead of crashing.

import os
import sys

# run the program as it is
# when the program stops and asks for a file
# name, type something like "bad_file" into
# the terminal

# find out the name of the Exception that happens

# add a try-except block around this line
# of code to handle this Exception.
# in the except-block, print "File does not exist"
# and use sys.exit(1) to end the program
file_name = input("File name: ")

print("File size:", os.path.getsize(file_name), "bytes")
