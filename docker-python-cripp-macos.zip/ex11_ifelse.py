# Goal: The program shall ask the user two questions. Then based on the answers
#       it will reply with "Welcome!" or with "Access denied!"

from decimal import Decimal

temperature = Decimal(input('Temperature: '))
trace_together = input('Trace Together Check-in (yes/no): ')

# create an if-else clause here
# if the temperature is less than 38 degrees
# and the trace_together checking answer equals "yes"
# then print "Welcome!"
# otherwise print "Access denied!"
???
???
???
???
