# Goal: We want to learn about the import syntax.

# From the module called "datetime" import the member called "date"
# in the same line, also import the member called "timedelta"
???

today = date.today()
future = today + timedelta(days=300)

print(future)