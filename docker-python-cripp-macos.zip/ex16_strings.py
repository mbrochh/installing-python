# Goal: We want to use slicing to seperate the text below into
#       `some_file_name` and `txt`.

file_name = 'some_file_name.txt'

# use slicing on the file_name variable
# so that you store everything from the
# beginning to the dot (excluding) into the
# name variable
name = ???

# use slicing again so that you store
# everything from dot (excluding) to the end in the 
# extension variable
extension = ???

print(name, extension)
