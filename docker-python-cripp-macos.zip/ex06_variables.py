# Goal: Just run this program and look at the two outputs.
#       Can you see the problem with floats and how Decimal fixes the issue?

from decimal import Decimal

val1 = 0.1
val2 = 0.2
print(val1 + val2)  # bad

val1 = Decimal("0.1")
val2 = Decimal("0.2")
print(val1 + val2)  # good
