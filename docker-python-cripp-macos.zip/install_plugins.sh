#!/bin/bash
code --install-extension ms-python.python \
     --install-extension charliermarsh.ruff \
     --install-extension ms-toolsai.jupyter \
     --install-extension ms-toolsai.jupyter-renderers