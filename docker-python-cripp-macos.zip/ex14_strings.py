# Goal: We want to print all our recipe filenames on the screen, but in all
#       lowercase and spaces replaced with underscores.

import os
files = os.listdir('./recipes')

for file in files:
    # create a new variable called new_file
    # the value of the new variable shall be
    # the value of the current file, 
    # but all lowercase
    ???
    # then use the replace() function on new_file to
    # replace empty spaces in with underscores
    ??? 
    print(new_file)

