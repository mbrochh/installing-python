# Goal: we want to add a number to the list and then sort the list

numbers = [4, 1, 9, 3]
# add the number 5 to the list
???

# now sort the list
???
print(numbers)
