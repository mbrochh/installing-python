# Goal: We want to increase a variable by 1

# create a variable called counter
# assign the integer 1 to this variable
???

# now increase the variable by 1
???

print(counter)
